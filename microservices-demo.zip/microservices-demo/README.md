# Microservices Demo project for Spring boot

## 1. Microservices 1 Twitter for Kafka