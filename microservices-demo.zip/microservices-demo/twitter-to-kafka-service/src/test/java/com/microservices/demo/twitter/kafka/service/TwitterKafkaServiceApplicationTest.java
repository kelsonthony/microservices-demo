package com.microservices.demo.twitter.kafka.service;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class TwitterKafkaServiceApplicationTest {

    @Disabled
    public void contextLoads() {
    }
}